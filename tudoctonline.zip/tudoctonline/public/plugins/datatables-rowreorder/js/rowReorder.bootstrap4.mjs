/*! Bootstrap 4 styling wrapper for RowReorder
 * © SpryMedia Ltd - datatables.net/license
 */

import jQuery from 'jquery';
import DataTable from 'datatables.net-bs4';
import RowReorder from 'datatables.net-rowreorder';

// Allow reassignment of the $ variable
let $ = jQuery;



export default DataTable;
